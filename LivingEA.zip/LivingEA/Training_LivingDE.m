%% ================= Training Phase =================

tic
clc
clear
close all

network_types = {'TCN', 'Temp-Transformer'};
Ensemble_Models = struct();

fprintf('==============================================================\n');
fprintf('Initializing Offline Agent-based Ensemble Training with ENAS...\n');
fprintf('Target Meta-Controllers: %s\n', strjoin(network_types, ', '));
fprintf('==============================================================\n\n');

for net_idx = 1:length(network_types)
    current_net = network_types{net_idx};
    fprintf('>>> Now Training: [%s] <<<\n', current_net);

    [current_gbestX, current_Pop_w, current_fitness] = Run_3Tier_Optimization(current_net);

    fprintf('>>> [%s] Training Concluded. Aggregated Fitness: %.4f <<<\n\n', current_net, current_fitness);

    safe_name = strrep(current_net, '-', '_');
    Ensemble_Models.(safe_name).w = current_Pop_w;
    Ensemble_Models.(safe_name).Hyper = current_gbestX;
end

fprintf('==============================================================\n');
fprintf('>>> All Agent-based Meta-Controllers Trained and Assembled! <<<\n');
fprintf('Saving to [Ensemble_MetaControllers_v4_PureBinomial.mat]...\n');
fprintf('==============================================================\n');

save('Ensemble_MetaControllers.mat', 'Ensemble_Models', '-v7');
toc

%% Three-Tier Neuroevolution Optimization
% Tier 1: Evolutionary Neural Architecture Search
function [Upper_gbestX, Pop_w, Upper_gbestfitness] = Run_3Tier_Optimization(net_type)

Upper_Np = 10;
MaxUp_iter = 10;

base_Ub = [30, 5, 50, 50, 50, 5];
base_Lb = [4,  1, 10, 10, 10, 1];

if strcmp(net_type, 'Temp-Transformer')
    Upper_Ub = [base_Ub, 4.499]; Upper_Lb = [base_Lb, 0.5];
elseif strcmp(net_type, 'TCN')
    Upper_Ub = [base_Ub, 5.499]; Upper_Lb = [base_Lb, 1.5];
end

Upper_Dim = length(Upper_Ub);

Upper_F = 0.5; Upper_CR = 0.9;
Upper_X = Upper_Lb + rand(Upper_Np, Upper_Dim) .* (Upper_Ub - Upper_Lb);
Upper_V = Upper_X; Upper_U = Upper_X;
Upper_Fitness = inf(1, Upper_Np);
Pop_w_pool = cell(1, Upper_Np);

for i = 1:Upper_Np
    Upper_X(i, :) = min(max(Upper_X(i, :), Upper_Lb), Upper_Ub);
    Upper_X(i, 1:6) = round(Upper_X(i, 1:6));
    
    [Upper_Fitness(i), Pop_w_pool{i}] = Framework_middle(Upper_X(i, :), net_type);
end

[Upper_gbestfitness, best_idx] = min(Upper_Fitness);
Upper_gbestX = Upper_X(best_idx, :);
Pop_w = Pop_w_pool{best_idx};

for Up_iter = 1 : MaxUp_iter
    fprintf('    [Neuroevolution] Iteration: %d / %d\n', Up_iter, MaxUp_iter);
    for i = 1 : Upper_Np
        Upper_r = randperm(Upper_Np, 4); Upper_r(Upper_r == i) = [];
        Upper_V(i, :) = Upper_X(Upper_r(1), :) + Upper_F * (Upper_X(Upper_r(2), :) - Upper_X(Upper_r(3), :));

        temp = randi([1, Upper_Dim]);
        for j = 1 : Upper_Dim
            if (rand <= Upper_CR || j == temp), Upper_U(i,j) = Upper_V(i,j);
            else, Upper_U(i,j) = Upper_X(i,j); end
        end
        Upper_U(i, :) = min(max(Upper_U(i, :), Upper_Lb), Upper_Ub);
        Upper_U(i, 1:6) = round(Upper_U(i, 1:6));

        [U_fit_raw, UPop_w_temp] = Framework_middle(Upper_U(i, :), net_type);
        
        if U_fit_raw < Upper_Fitness(i)
            Upper_X(i,:) = Upper_U(i,:);
            Upper_Fitness(i) = U_fit_raw; 
            Pop_w_pool{i} = UPop_w_temp;

            if U_fit_raw < Upper_gbestfitness
                Upper_gbestfitness = U_fit_raw;
                Upper_gbestX = Upper_X(i,:);
                Pop_w = UPop_w_temp;
            end
        end
    end
end
end

% Tier 2: Neuroevolutionary Weight Optimization
function [Upper_Fitness_i, UPop_w] = Framework_middle(Upper_X_i, net_type)
Dim = 10;
Np = 100;
ub = 100; lb = -100;
Func_train = @cec22_func;
M = 1:12;

GTF = 0.5; GTCR = 0.9;
GTNp = Upper_X_i(1); lay_K = Upper_X_i(2); Trajectory_length = Upper_X_i(3);
Trajectory_num = Upper_X_i(4); d_model = Upper_X_i(5); K_sequence = Upper_X_i(6);
spec_param = Upper_X_i(7); 

W = [];

for l = 1:lay_K
    if l == 1, in_dim = 3; else, in_dim = d_model; end

    switch net_type
        case 'Temp-Transformer'
            ffn_ratio = round(spec_param);
            num_params = 0;
            if l == 1, num_params = num_params + (in_dim * d_model + d_model); in_dim = d_model; end
            num_params = num_params + 3*(in_dim * d_model + d_model) + ...
                         (d_model * (ffn_ratio*d_model) + ffn_ratio*d_model) + ...
                         ((ffn_ratio*d_model) * d_model + d_model);
        case 'TCN'
            k_size = round(spec_param);
            num_params = (k_size * in_dim * d_model) + d_model;
    end
    W_layer = randn(1, num_params) * sqrt(1/(in_dim+1e-8)) * 0.1;
    W = [W, W_layer];
end

W_output = randn(1, (d_model * 42) + 42) * 0.1;
W = [W, W_output];
w_len = length(W);

w_gbestfitness = inf;
GTx = randn(GTNp, w_len); GTu = randn(GTNp, w_len); GTv = randn(GTNp, w_len);
GTx(1, :) = W;
arfitness = inf(1, GTNp); newarfitness = zeros(1, GTNp);

for Trajectory_no = 1:Trajectory_num
    for GTi = 1:GTNp
        r = randperm(GTNp, 4); r(r==GTi) = [];
        GTv(GTi,:) = GTx(r(1),:) + GTF*(GTx(r(2),:) - GTx(r(3),:));
        mask = rand(1, w_len) <= GTCR; temp_mask = (1:w_len) == randi(w_len);
        GTu(GTi, :) = (mask | temp_mask) .* GTv(GTi,:) + ~(mask | temp_mask) .* GTx(GTi,:);

        w_perturbed = GTu(GTi,:);
        gap_gbestfitness = inf(1, length(M));
        fmin = 0;

        parfor f_idx = 1:length(M)
            FuncId = M(f_idx);
            [gbestfitness_cma] = Learned_X(w_perturbed, Np, Dim, lb, ub, d_model, Trajectory_length, Func_train, FuncId, lay_K, K_sequence, net_type, spec_param);
            gap_gbestfitness(f_idx) = log(1 + (gbestfitness_cma - fmin));
        end

        newarfitness(GTi) = sum(gap_gbestfitness);
        if newarfitness(GTi) < arfitness(GTi)
            arfitness(GTi) = newarfitness(GTi);
            GTx(GTi,:) = GTu(GTi,:);
            if w_gbestfitness > arfitness(GTi)
                w_gbestfitness = arfitness(GTi);
                W = GTx(GTi,:);
            end
        end
    end
end
Upper_Fitness_i = mean(arfitness);
UPop_w = W;
end

% Tier 3: Algorithm Design Evaluation
function [gbestfitness] = Learned_X(w_perturbed, N_init, Dim, xmin, xmax, d_model, Trajectory_length, Func, FuncId, lay_K, K_sequence, net_type, spec_param)

N = N_init; N_min = 4;

gbestfitness = inf;
x = xmin + (xmax - xmin) .* rand(N, Dim);
fitnessx = Func(x', FuncId);
[gbestfitness, mix] = min(fitnessx); gbestX = x(mix, :);

max_A_size = ceil(1.4 * N_init); A = xmin + (xmax - xmin) .* rand(max_A_size, Dim);

hist_input = zeros(K_sequence, N, 3);
success_counts = zeros(1, N);

for Iter = 1:Trajectory_length
    Distance = vecnorm(x - gbestX, 2, 2)';
    min_d = min(Distance); max_d = max(Distance);
    if max_d ~= min_d, nom_d = 1 - (Distance - min_d) / (max_d - min_d); else, nom_d = zeros(1, N); end

    min_f = min(fitnessx); max_f = max(fitnessx);
    if max_f ~= min_f, nom_f = (fitnessx - min_f) / (max_f - min_f); else, nom_f = zeros(1, N); end

    if Iter == 1
        succ_rate = zeros(1, N);
    else
        succ_rate = success_counts ./ (Iter - 1);
    end

    nom_df = [nom_f', nom_d', succ_rate'];

    if Iter == 1
        for k=1:K_sequence, hist_input(k,:,:) = nom_df; end
    else
        hist_input(1:K_sequence-1, :, :) = hist_input(2:K_sequence, :, :); hist_input(K_sequence, :, :) = nom_df;
    end

    [Theta] = Forward_Agent_MetaController(hist_input, w_perturbed, d_model, lay_K, net_type, spec_param);
    action_net = Theta.action_net;

    numRules = 4; numRuleSlots = 8; numSwitch = 4;
    rule_logits = reshape(action_net(1:32, :), numRules, numRuleSlots, N);
    rule_logits = rule_logits - max(rule_logits, [], 1);
    rule_probs = exp(rule_logits) ./ sum(exp(rule_logits), 1);
    m_rule = zeros(numRuleSlots, N, 'int32');
    for i = 1:N
        for s = 1:numRuleSlots
            act = find(rand <= cumsum(rule_probs(:, s, i)), 1, 'first');
            if isempty(act), act = 3; end; m_rule(s, i) = int32(act);
        end
    end

    sch_logits = action_net(33:36, :); sch_probs = 1 ./ (1 + exp(-sch_logits)); sch = double(rand(numSwitch, N) < sch_probs)';
    for i = 1:N, if sum(sch(i, :)) == 0, [~, maxIdx] = max(sch_probs(:, i)); sch(i, maxIdx) = 1; end; end

    num_A = size(A, 1); base_logits = action_net(37:40, :); base_logits = base_logits - max(base_logits, [], 1);
    base_probs = exp(base_logits) ./ sum(exp(base_logits), 1); base_vector = zeros(N, Dim);
    for i = 1:N
        act = find(rand <= cumsum(base_probs(:, i)), 1, 'first'); if isempty(act), act = 3; end
        if act == 4, base_vector(i, :) = A(randi(num_A), :); else, base_vector(i, :) = x(pick_index_by_rule_local(fitnessx, i, act), :); end
    end

    F = (1 ./ (1 + exp(-action_net(41, :))))';
    CR = (1 ./ (1 + exp(-action_net(42, :))))';

    [r_idx, r_src] = build_mutation_indices_rule_slots_local(fitnessx, m_rule', num_A);
    op1 = extract_operands_local(x, A, r_idx, r_src, 1); op2 = extract_operands_local(x, A, r_idx, r_src, 2);
    op3 = extract_operands_local(x, A, r_idx, r_src, 3); op4 = extract_operands_local(x, A, r_idx, r_src, 4);
    op5 = extract_operands_local(x, A, r_idx, r_src, 5); op6 = extract_operands_local(x, A, r_idx, r_src, 6);
    op7 = extract_operands_local(x, A, r_idx, r_src, 7); op8 = extract_operands_local(x, A, r_idx, r_src, 8);

    v = base_vector + F .* ((op1 - op2).*sch(:,1) + (op3 - op4).*sch(:,2) + (op5 - op6).*sch(:,3) + (op7 - op8).*sch(:,4));

    Mask = zeros(N, Dim);
    for i = 1:N
        Mask(i, :) = rand(1, Dim) <= CR(i);
        Mask(i, randi(Dim)) = 1; 
    end

    u = x + Mask .* (v - x);

    flagub = u > xmax; flaglb = u < xmin; flag = flagub | flaglb;
    u = u .* (~flag) + (xmin + (xmax - xmin) .* rand(N, Dim)) .* flag;

    ufitness = Func(u', FuncId);
    better = ufitness < fitnessx;

    success_counts = success_counts + better;

    if any(better), A = [A; x(better, :)]; if size(A, 1) > max_A_size, A = A(randperm(size(A, 1), max_A_size), :); end; end

    x(better, :) = u(better, :); fitnessx(better) = ufitness(better);
    [minf, mix] = min(fitnessx); if minf < gbestfitness, gbestfitness = minf; gbestX = x(mix, :); end

    N_new = round((N_min - N_init) / Trajectory_length * Iter + N_init);
    if N_new < N_min, N_new = N_min; end

    if N_new < N
        [~, sort_idx] = sort(fitnessx, 'ascend'); x = x(sort_idx(1:N_new), :); fitnessx = fitnessx(sort_idx(1:N_new));

        hist_input = hist_input(:, sort_idx(1:N_new), :);
        success_counts = success_counts(sort_idx(1:N_new));

        N = N_new;
        if size(A, 1) > round(1.4 * N), A = A(randperm(size(A, 1), round(1.4 * N)), :); end
    end
end
end

function [r_idx, r_src] = build_mutation_indices_rule_slots_local(fitness, rule_slots, num_A)
len_fit = numel(fitness); r_idx = zeros(len_fit, 8); r_src = zeros(len_fit, 8);
for i = 1:len_fit
    for j = 1:8
        ruleId = rule_slots(i, j);
        if ruleId == 4, r_src(i, j) = 2; r_idx(i, j) = randi(num_A); else, r_src(i, j) = 1; r_idx(i, j) = pick_index_by_rule_local(fitness, i, ruleId); end
    end
    pairs = [1 2; 3 4; 5 6; 7 8];
    for p = 1:size(pairs, 1)
        a = pairs(p, 1); b = pairs(p, 2);
        if r_src(i, a) == r_src(i, b) && r_idx(i, a) == r_idx(i, b)
            if r_src(i, a) == 2, altPool = setdiff(1:num_A, r_idx(i, a)); if isempty(altPool), altPool = 1:num_A; end; r_idx(i, b) = altPool(randi(numel(altPool)));
            else, altPool = setdiff(1:len_fit, [i, r_idx(i, a)]); if isempty(altPool), altPool = setdiff(1:len_fit, i); end; r_idx(i, b) = altPool(randi(numel(altPool))); end
        end
    end
end
end

function V = extract_operands_local(X, A, r_idx, r_src, col)
N = size(X, 1); D = size(X, 2); V = zeros(N, D);
mask_X = (r_src(:, col) == 1); mask_A = (r_src(:, col) == 2); V(mask_X, :) = X(r_idx(mask_X, col), :); if any(mask_A), V(mask_A, :) = A(r_idx(mask_A, col), :); end
end

function idx = pick_index_by_rule_local(fitness, selfIdx, ruleId)
len_fit = numel(fitness); [~, ind] = sort(fitness, 'ascend'); p_count = max(1, ceil(len_fit * 0.11)); pool = setdiff(1:len_fit, selfIdx);
switch ruleId, case 1, cand = ind(1:p_count); case 2, cand = pool; case 3, idx = selfIdx; return; otherwise, cand = pool; end
cand(cand == selfIdx) = []; if isempty(cand), cand = pool; end; idx = cand(randi(numel(cand)));
end