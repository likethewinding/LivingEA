%% ================= Testing Phase =================

clear;
clc;
cd(fileparts(mfilename('fullpath')));

%% Test settings
D = 10;                         % Common choices: 10, 30, 50, 100.
lb = -100;
ub = 100;
MaxFEs = 10000 * D;
N = ceil(60 * sqrt(D) * log(1 + D));
FuncIds = [1, 3:30];             % CEC2017 excludes F2.
NumRuns = 30;
BaseSeed = 1;
Func = @cec17_func;

assert(isfile('Ensemble_MetaControllers.mat'), 'Missing pretrained model.');
assert(exist('cec17_func', 'file') == 3, 'Missing compatible CEC2017 MEX.');
assert(isfolder('input_data_17'), 'Missing CEC2017 input_data_17 folder.');
assert(N >= 4 && MaxFEs >= N, 'The evaluation budget must cover initialization.');

%% Output directories
resultRoot = fullfile(pwd, 'results_testing');
if ~isfolder(resultRoot), mkdir(resultRoot); end

outputDir = tempname(resultRoot);
mkdir(outputDir);

figureDir = fullfile(outputDir, 'figures');
mkdir(figureDir);

fprintf('CEC2017: D=%d, initial population=%d, budget=%d, runs=%d\n', ...
    D, N, MaxFEs, NumRuns);
fprintf('Results: %s\n', outputDir);

%% Plot settings (adapted from run_FEs.m)
PlotColor = [0.3294, 0.4392, 0.7765];
PlotFloor = 1e-16;

%% Sequential testing across functions
for k = 1:numel(FuncIds)

    FuncId = FuncIds(k);

    fprintf('\n========== Start CEC2017 F%d (%d/%d) ==========\n', ...
        FuncId, k, numel(FuncIds));

    Gbest_X = zeros(NumRuns, D);
    Gbest_Fitness = nan(NumRuns, 1);
    Gbest_History = nan(NumRuns, MaxFEs);
    Seeds = zeros(NumRuns, 1);
    ElapsedSeconds = zeros(NumRuns, 1);

    %% Parallel independent runs
    parfor r = 1:NumRuns

        seed = BaseSeed + (FuncId - 1) * NumRuns + r - 1;
        Seeds(r) = seed;
        rng(seed, 'twister');

        started = tic;

        [gbestX, gbestfitness, gbesthistory] = ...
            LivingDE(N, D, ub, lb, MaxFEs, Func, FuncId);

        ElapsedSeconds(r) = toc(started);

        Gbest_X(r, :) = gbestX;
        Gbest_Fitness(r) = gbestfitness;
        Gbest_History(r, :) = gbesthistory;

        fprintf('LivingDE F%d D%d run %d/%d: error = %.6E (%.1f s)\n', ...
            FuncId, D, r, NumRuns, gbestfitness, ElapsedSeconds(r));
    end

    %% Statistics and data saving
    MeanError = mean(Gbest_Fitness);
    StdError = std(Gbest_Fitness);

    save(fullfile(outputDir, sprintf('LivingDE_F%02d_D%d.mat', FuncId, D)), ...
        'Gbest_X', 'Gbest_Fitness', 'Gbest_History', 'MeanError', 'StdError', ...
        'Seeds', 'ElapsedSeconds', 'D', 'N', 'lb', 'ub', 'MaxFEs', ...
        'FuncId', 'NumRuns', 'BaseSeed', '-v7.3');

    fprintf('F%d: mean error = %.6E, sample std = %.6E\n', ...
        FuncId, MeanError, StdError);

    %% Mean convergence curve
    Avg_History = mean(Gbest_History, 1);
    PlotHistory = max(Avg_History, PlotFloor);
    markerStep = max(1, floor(MaxFEs / 20));

    h1 = figure('Visible', 'off', 'Name', 'Convergence curve', ...
        'NumberTitle', 'off');

    semilogy(1:MaxFEs, PlotHistory, 'LineWidth', 1.2, ...
        'Color', PlotColor, 'LineStyle', '-', 'Marker', 's', ...
        'MarkerSize', 6, 'MarkerIndices', 1:markerStep:MaxFEs);

    xlim([0 MaxFEs]);
    xlabel('FEs', 'FontSize', 12);
    ylabel('Mean error', 'FontSize', 12);
    set(gca, 'YScale', 'log');

    lgd = legend('LivingDE');
    lgd.FontSize = 8;
    lgd.Location = 'southwest';
    set(lgd, 'LineWidth', 1);

    set(h1, 'Units', 'inches', 'Position', [1 1 4 4]);

    exportgraphics(h1, fullfile(figureDir, ...
        sprintf('ConvergenceF%d_%d.pdf', FuncId, D)), 'Resolution', 300);

    close(h1);

    %% Final-error boxplot
    if NumRuns > 1

        PlotFitness = max(Gbest_Fitness, PlotFloor);

        h2 = figure('Visible', 'off', 'Name', 'Final error boxplot', ...
            'NumberTitle', 'off');

        boxplot(PlotFitness, 'Colors', PlotColor, 'Labels', {'LivingDE'});
        hold on;

        % Semi-transparent colored box.
        boxHandles = findobj(gca, 'Tag', 'Box');
        for z = 1:numel(boxHandles)
            patch(get(boxHandles(z), 'XData'), ...
                get(boxHandles(z), 'YData'), PlotColor, 'FaceAlpha', 0.6);
        end

        % Hollow sample points on the left.
        xPos = linspace(0.4, 0.6, NumRuns)';
        scatter(xPos, PlotFitness, 5, PlotColor, 'o', ...
            'MarkerEdgeColor', PlotColor, 'MarkerFaceColor', 'none');

        xlim([0 2]);
        title(sprintf('Boxplot on F%d', FuncId));
        ylabel('Final error', 'FontSize', 12);
        set(gca, 'XTickLabelRotation', 45, 'YScale', 'log');
        hold off;

        set(h2, 'Units', 'inches', 'Position', [1 1 4 4]);

        exportgraphics(h2, fullfile(figureDir, ...
            sprintf('BoxplotF%d_%d.pdf', FuncId, D)), 'Resolution', 300);

        close(h2);
    end

    fprintf('F%d completed: %d runs, MAT saved, figures exported.\n', ...
        FuncId, NumRuns);
end

fprintf('\nTesting completed. Results: %s\n', outputDir);
fprintf('Figures saved to: %s\n', figureDir);
