function [gbestX, gbestfitness, gbesthistory] = LivingDE(N, Dim, ub, lb, MaxFEs, Func, FuncId)

N_init = N;
N_min = 4;

if isscalar(lb), lb = repmat(lb, 1, Dim); end
if isscalar(ub), ub = repmat(ub, 1, Dim); end
xmin = lb; xmax = ub;

%% Load Pretrained Meta-Controllers
persistent Ensemble_Models;
if isempty(Ensemble_Models)
    modelFile = 'Ensemble_MetaControllers.mat'; 
    if exist(modelFile, 'file')
        data = load(modelFile);
        Ensemble_Models = data.Ensemble_Models;
    else
        error('Cannot find trained ensemble model file. Please train first.');
    end
end

net_names = {'TCN', 'Temp_Transformer'};
num_nets = length(net_names);

Net_Hypers = struct();
max_K_sequence = 1;

for i = 1:num_nets
    net_str = net_names{i};
    hyper = Ensemble_Models.(net_str).Hyper;
    Net_Hypers.(net_str).lay_K = hyper(2);
    Net_Hypers.(net_str).cell_size = hyper(5);
    Net_Hypers.(net_str).K_seq = hyper(6);
    Net_Hypers.(net_str).spec_param = hyper(7);

    if hyper(6) > max_K_sequence, max_K_sequence = hyper(6); end
end

Q_table = zeros(1, num_nets);
alpha = 0.1; gamma = 0.9;

%% Initialize Population and Temporal Features
x = xmin + (xmax - xmin) .* rand(N_init, Dim);
fitnessx = Func(x', FuncId);
fitnessx = fitnessx(:); 
[gbestfitness, mix] = min(fitnessx); gbestX = x(mix, :);

max_A_size = ceil(1.4 * N_init);
A = xmin + (xmax - xmin) .* rand(max_A_size, Dim);

global_hist_input = zeros(max_K_sequence, N_init, 3);
success_counts = zeros(N_init, 1);
Iter_count = 0;

FEs = N_init;
gbesthistory = inf(1, MaxFEs);
gbesthistory(1:min(FEs, MaxFEs)) = gbestfitness;

first_iter = true;

%% Main Evolution Loop with Q-Learning
while FEs < MaxFEs
    Iter_count = Iter_count + 1;
    
    [~, global_sorted_idx] = sort(fitnessx, 'ascend');
    p_count = max(1, ceil(N * 0.11)); 

    Distance = vecnorm(x - gbestX, 2, 2);
    min_d = min(Distance); max_d = max(Distance);
    if max_d ~= min_d, nom_d = 1 - (Distance - min_d) / (max_d - min_d); else, nom_d = zeros(N, 1); end

    min_f = min(fitnessx); max_f = max(fitnessx);
    if max_f ~= min_f, nom_f = (fitnessx - min_f) / (max_f - min_f); else, nom_f = zeros(N, 1); end

    if Iter_count == 1
        succ_rate = zeros(N, 1);
    else
        succ_rate = success_counts ./ (Iter_count - 1);
    end

    nom_df = [nom_f, nom_d, succ_rate];

    if first_iter
        for k=1:max_K_sequence, global_hist_input(k,:,:) = nom_df; end
        first_iter = false;
    else
        global_hist_input(1:max_K_sequence-1, :, :) = global_hist_input(2:max_K_sequence, :, :);
        global_hist_input(max_K_sequence, :, :) = nom_df;
    end

    current_epsilon = 1.0 - 0.95 * (FEs / MaxFEs);

    if rand < current_epsilon
        chosen_idx = randi(num_nets);
    else
        [~, chosen_idx] = max(Q_table);
    end

    net_str = net_names{chosen_idx};
    current_W = Ensemble_Models.(net_str).w;
    lK = Net_Hypers.(net_str).lay_K;
    cs = Net_Hypers.(net_str).cell_size;
    k_seq = Net_Hypers.(net_str).K_seq;
    spec_param = Net_Hypers.(net_str).spec_param;

    net_hist = global_hist_input(max_K_sequence - k_seq + 1 : max_K_sequence, :, :);

    if strcmp(net_str, 'Temp_Transformer')
        forward_name = 'Temp-Transformer';
    else
        forward_name = net_str;
    end

    [Theta] = Forward_Agent_MetaController(net_hist, current_W, cs, lK, forward_name, spec_param);
    action_net = Theta.action_net;

    % =========================================================================
    % 网络策略解码 
    % =========================================================================
    numRules = 4; numRuleSlots = 8; numSwitch = 4;
    m_rule = zeros(numRuleSlots, N, 'int32');
    base_vector = zeros(N, Dim);
    num_A = size(A, 1);

    rule_logits = reshape(action_net(1:32, :), numRules, numRuleSlots, N);
    rule_logits = rule_logits - max(rule_logits, [], 1);
    rule_probs = exp(rule_logits) ./ sum(exp(rule_logits), 1);
    for i = 1:N
        for s = 1:numRuleSlots
            act = find(rand <= cumsum(rule_probs(:, s, i)), 1, 'first');
            if isempty(act), act = 3; end; m_rule(s, i) = int32(act);
        end
    end

    sch_logits = action_net(33:36, :);
    sch_probs = 1 ./ (1 + exp(-sch_logits));
    sch = double(rand(numSwitch, N) < sch_probs)';
    for i = 1:N, if sum(sch(i, :)) == 0, [~, maxIdx] = max(sch_probs(:, i)); sch(i, maxIdx) = 1; end; end

    base_logits = action_net(37:40, :);
    base_logits = base_logits - max(base_logits, [], 1);
    base_probs = exp(base_logits) ./ sum(exp(base_logits), 1);
    for i = 1:N
        act = find(rand <= cumsum(base_probs(:, i)), 1, 'first'); if isempty(act), act = 3; end
        if act == 4
            base_vector(i, :) = A(randi(max(1, num_A)), :); 
        else
            base_vector(i, :) = x(pick_index_by_rule_local_fast(N, i, act, global_sorted_idx, p_count), :); 
        end
    end

    F = (1 ./ (1 + exp(-action_net(41, :))))';
    CR = (1 ./ (1 + exp(-action_net(42, :))))';

    [r_idx, r_src] = build_mutation_indices_rule_slots_local(fitnessx, m_rule', num_A, global_sorted_idx, p_count);
    
    op1 = extract_operands_local(x, A, r_idx, r_src, 1); op2 = extract_operands_local(x, A, r_idx, r_src, 2);
    op3 = extract_operands_local(x, A, r_idx, r_src, 3); op4 = extract_operands_local(x, A, r_idx, r_src, 4);
    op5 = extract_operands_local(x, A, r_idx, r_src, 5); op6 = extract_operands_local(x, A, r_idx, r_src, 6);
    op7 = extract_operands_local(x, A, r_idx, r_src, 7); op8 = extract_operands_local(x, A, r_idx, r_src, 8);

    v = base_vector + F .* ((op1 - op2).*sch(:,1) + (op3 - op4).*sch(:,2) + (op5 - op6).*sch(:,3) + (op7 - op8).*sch(:,4));

    Mask = rand(N, Dim) <= repmat(CR, 1, Dim);
    
    rand_dims = randi(Dim, N, 1);
    linear_idx = sub2ind([N, Dim], (1:N)', rand_dims);
    Mask(linear_idx) = 1;

    u = x + Mask .* (v - x);

    flagub = u > xmax; flaglb = u < xmin; flag = flagub | flaglb;
    u = u .* (~flag) + (xmin + (xmax - xmin) .* rand(N, Dim)) .* flag;

    ufitness = Func(u', FuncId);
    ufitness = ufitness(:);

    better = ufitness < fitnessx;

    success_counts = success_counts + better;

    improves = max(0, fitnessx - ufitness);
    Reward = mean(log(1 + improves));
    max_next_Q = max(Q_table);

    Q_table(chosen_idx) = Q_table(chosen_idx) + alpha * (Reward + gamma * max_next_Q - Q_table(chosen_idx));

    if any(better)
        A = [A; x(better, :)];
        if size(A, 1) > max_A_size, A = A(randperm(size(A, 1), max_A_size), :); end
    end

    x(better, :) = u(better, :); fitnessx(better) = ufitness(better);
    [minf, mix] = min(fitnessx); if minf < gbestfitness, gbestfitness = minf; gbestX = x(mix, :); end

    oldFEs = FEs; FEs = FEs + N;
    gbesthistory(oldFEs + 1 : min(FEs, MaxFEs)) = gbestfitness;

    N_new = round((N_min - N_init) / MaxFEs * FEs + N_init);
    if N_new < N_min, N_new = N_min; end

    if N_new < N
        [~, sort_idx] = sort(fitnessx, 'ascend');
        x = x(sort_idx(1:N_new), :); fitnessx = fitnessx(sort_idx(1:N_new));

        global_hist_input = global_hist_input(:, sort_idx(1:N_new), :);
        success_counts = success_counts(sort_idx(1:N_new));

        N = N_new;
        if size(A, 1) > round(1.4 * N), A = A(randperm(size(A, 1), round(1.4 * N)), :); end
    end

end

if FEs < MaxFEs, gbesthistory(FEs + 1:MaxFEs) = gbestfitness;
elseif FEs > MaxFEs, gbesthistory = gbesthistory(1:MaxFEs); end

end

%% Neural Network Forward Pass
function [Theta] = Forward_Agent_MetaController(hist_input, Wall, d_model, lay_K, net_type, spec_param)
N = size(hist_input, 2);
offset = 0;
relu = @(x) max(0, x);
softmax_local = @(x) exp(x - max(x, [], 2)) ./ sum(exp(x - max(x, [], 2)), 2);

rmsnorm = @(x) x ./ sqrt(mean(x.^2, 2) + 1e-5);

K_seq = size(hist_input, 1);
layer_input_seq = hist_input;

for l = 1:lay_K
    in_dim = size(layer_input_seq, 3);

    switch net_type
        case 'Temp-Transformer'
            ffn_ratio = round(spec_param);

            seq_flat = reshape(layer_input_seq, K_seq * N, in_dim);
            if l == 1
                W_proj = reshape(Wall(offset+1:offset+in_dim*d_model), in_dim, d_model); offset = offset + in_dim*d_model;
                b_proj = Wall(offset+1:offset+d_model); offset = offset + d_model;
                seq_flat = seq_flat * W_proj + b_proj;
                in_dim = d_model;
            end

            Wq = reshape(Wall(offset+1:offset+in_dim*d_model), in_dim, d_model); offset = offset + in_dim*d_model; bq = Wall(offset+1:offset+d_model); offset = offset + d_model;
            Wk = reshape(Wall(offset+1:offset+in_dim*d_model), in_dim, d_model); offset = offset + in_dim*d_model; bk = Wall(offset+1:offset+d_model); offset = offset + d_model;
            Wv = reshape(Wall(offset+1:offset+in_dim*d_model), in_dim, d_model); offset = offset + in_dim*d_model; bv = Wall(offset+1:offset+d_model); offset = offset + d_model;

            Q = reshape(seq_flat * Wq + bq, K_seq, N, d_model);
            K_mat = reshape(seq_flat * Wk + bk, K_seq, N, d_model);
            V = reshape(seq_flat * Wv + bv, K_seq, N, d_model);

            new_seq = zeros(K_seq, N, d_model);
            for n = 1:N
                Q_n = reshape(Q(:, n, :), K_seq, d_model);
                K_n = reshape(K_mat(:, n, :), K_seq, d_model);
                V_n = reshape(V(:, n, :), K_seq, d_model);
                attn = softmax_local((Q_n * K_n') / sqrt(d_model)) * V_n;
                new_seq(:, n, :) = attn;
            end

            X_res = seq_flat + reshape(new_seq, K_seq * N, d_model);
            X_res = rmsnorm(X_res);

            Wf1 = reshape(Wall(offset+1:offset+d_model*(ffn_ratio*d_model)), d_model, ffn_ratio*d_model); offset=offset+d_model*(ffn_ratio*d_model);
            bf1 = Wall(offset+1:offset+ffn_ratio*d_model); offset=offset+ffn_ratio*d_model;
            Wf2 = reshape(Wall(offset+1:offset+(ffn_ratio*d_model)*d_model), ffn_ratio*d_model, d_model); offset=offset+(ffn_ratio*d_model)*d_model;
            bf2 = Wall(offset+1:offset+d_model); offset=offset+d_model;

            seq_flat = X_res + relu(X_res * Wf1 + bf1) * Wf2 + bf2;
            seq_flat = rmsnorm(seq_flat);
            layer_input_seq = reshape(seq_flat, K_seq, N, d_model);

        case 'TCN'
            k_size = round(spec_param);

            W_conv = reshape(Wall(offset+1:offset+k_size*in_dim*d_model), k_size*in_dim, d_model); offset = offset + k_size*in_dim*d_model;
            b_conv = Wall(offset+1:offset+d_model); offset = offset + d_model;

            new_seq = zeros(K_seq, N, d_model);
            for t = 1:K_seq
                patch = zeros(N, k_size * in_dim);
                for k_step = 1:k_size
                    step_idx = t - k_size + k_step;
                    if step_idx > 0
                        patch(:, (k_step-1)*in_dim+1 : k_step*in_dim) = reshape(layer_input_seq(step_idx,:,:), N, in_dim);
                    end
                end
                out_t = relu(patch * W_conv + b_conv);
                new_seq(t,:,:) = rmsnorm(out_t);
            end
            layer_input_seq = new_seq;
    end
end

final_feat = reshape(layer_input_seq(end, :, :), N, d_model);
W_out = reshape(Wall(offset+1 : offset+d_model*42), d_model, 42); offset = offset + d_model*42;
b_out = Wall(offset+1 : offset+42);

out_flat = final_feat * W_out + b_out;
out_flat = max(min(out_flat, 10), -10);

Theta.action_net = out_flat';
end

%% Local Helper Functions
function [r_idx, r_src] = build_mutation_indices_rule_slots_local(fitness, rule_slots, num_A, sorted_idx, p_count)
    len_fit = numel(fitness); 
    r_idx = zeros(len_fit, 8); 
    r_src = zeros(len_fit, 8);
    
    for i = 1:len_fit
        for j = 1:8
            ruleId = rule_slots(i, j);
            if ruleId == 4
                r_src(i, j) = 2; 
                r_idx(i, j) = randi(max(1, num_A)); 
            else
                r_src(i, j) = 1; 
                r_idx(i, j) = pick_index_by_rule_local_fast(len_fit, i, ruleId, sorted_idx, p_count); 
            end
        end
        
        pairs = [1 2; 3 4; 5 6; 7 8];
        for p = 1:size(pairs, 1)
            a = pairs(p, 1); b = pairs(p, 2);
            if r_src(i, a) == r_src(i, b) && r_idx(i, a) == r_idx(i, b)
                if r_src(i, a) == 2 
                    if num_A > 1
                        while r_idx(i, b) == r_idx(i, a)
                            r_idx(i, b) = randi(num_A);
                        end
                    end
                else 
                    if len_fit > 2
                        while r_idx(i, b) == r_idx(i, a) || r_idx(i, b) == i
                            r_idx(i, b) = randi(len_fit);
                        end
                    end
                end
            end
        end
    end
end

function idx = pick_index_by_rule_local_fast(len_fit, selfIdx, ruleId, sorted_idx, p_count)
    switch ruleId

        case 1  
            idx = sorted_idx(randi(p_count));

            if p_count > 1
                while idx == selfIdx
                    idx = sorted_idx(randi(p_count));
                end
            else
                if idx == selfIdx && len_fit > 1
                    idx = randi(len_fit - 1);
                    if idx >= selfIdx
                        idx = idx + 1;
                    end
                end
            end

        case 2  
            if len_fit > 1
                idx = randi(len_fit - 1);
                if idx >= selfIdx
                    idx = idx + 1;
                end
            else
                idx = selfIdx;
            end

        case 3  
            idx = selfIdx;

        otherwise
            if len_fit > 1
                idx = randi(len_fit - 1);
                if idx >= selfIdx
                    idx = idx + 1;
                end
            else
                idx = selfIdx;
            end
    end
end

function V = extract_operands_local(X, A, r_idx, r_src, col)
    N = size(X, 1); D = size(X, 2); V = zeros(N, D);
    mask_X = (r_src(:, col) == 1); mask_A = (r_src(:, col) == 2); 
    V(mask_X, :) = X(r_idx(mask_X, col), :); 
    if any(mask_A) && size(A, 1) > 0
        V(mask_A, :) = A(r_idx(mask_A, col), :); 
    end
end
